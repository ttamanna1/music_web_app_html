Files you put in this folder are served by Flask. You can use it to serve
images, CSS files, and other things.

To see an example, run the server and visit [this URL](http://localhost:5001/static/tdd-iceberg.png)
